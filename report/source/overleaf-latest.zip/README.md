# Report draft: Harvesting under a Strong Allee Effect

AI-assisted first full draft for the five members to edit section by section. Upload the ZIP to Overleaf as a new project, set **Main document = `main.tex`** and **Compiler = pdfLaTeX**, then recompile. Compile `main.tex`, never a section file.

## Source used
- Evidence branch: PR #5 `integration/final-deliverables-draft`, head `ef3c9a57569ce7efb662d323220ded455d63dd2e` (final notebook integrated at `f006310`).
- PINN branch content: PR #10 `integration/shared-pinn-settings`, head `a0cbbc974f7ea0c6694ef504ef2bcdec6f77cd56` (includes the review fixes `008c776` and `a0cbbc9` that PR #5 did not yet contain; the report states those corrections).
- Prose follows Prem's and Rohan's edited notebook `project_colab_markdown_fixed.ipynb` (plain language, same section order and the same content kept or dropped), with the factual corrections of PR #5/#10 applied (B near-fold recovers 3/3; held-out window is physics-supported prediction).
- Template: `docs/course/overleaf_blank_template.zip` from PR #5 (12pt A4, preamble, title block and input order unchanged).

## Layout and editing owners
| File | Owner |
|---|---|
| `frontmatter.tex` (introduction, objectives, assumptions, notation), `abstract.tex`, `sections/conclusions.tex`, `sections/acknowledgements.tex` | shared, coordinated by Devam |
| `sections/01_foundations.tex` | Raghav (WP01) |
| `sections/02_model_b_history.tex` | Ashwath (WP02) |
| `sections/03_collapse.tex` | Devam (WP03) |
| `sections/04_forward_pinn.tex` | Prem (WP04) |
| `sections/05_inverse_validation.tex` | Rohan (WP05); Prem's shared-engine contribution is reconciled in it |
| `preamble.tex`, `references.bib` | shared |

Section numbers are automatic (the introduction is Section 1, WP01 is Section 2, ... WP05 is Section 6). All cross references use `\ref`, `\eqref` and `\cite`.

## Figures
`figures/` holds the EPS originals and matching PDF companions (named `<name>-eps-converted-to.pdf`, so the build does not depend on Ghostscript at upload time). All figures are cited in the text.

| Figure | Source |
|---|---|
| `wp01_logistic_vs_allee`, `wp01_model_a_branches`, `wp01_model_a_perturbations` | `artifacts/figures/` (WP01) |
| `wp02_b_branches`, `wp02_history` | `artifacts/figures/` (WP02) |
| `wp03_basins`, `wp03_extinction`, `wp03_bottleneck`, `wp03_sensitivity_yield`, `wp03_rk45_reference` | `artifacts/figures/` (WP03) |
| `wp04_forward`, `wp04_error_loss` | `artifacts/figures/` (WP04) |
| `wp05_recovery_noise`, `wp05_heldout_failure` | **regenerated** by re-running `configs/wp05_final.json` with alpha-free colours (see below) |
| `wp05_splits`, `wp05_counterexample` | **new**, made by `tools/make_extra_figs.py` with the repository code (illustration of the split and of the Model B counterexample) |

Not used: `wp04_diagnose` and the `*_original_settings` figures (the diagnostic is described as a companion study; the original-settings comparison is text only).

**Why two WP05 figures were regenerated.** The committed EPS files lost the transparency of the shaded train/validation/test bands (PostScript has no transparency), so the bands rendered as saturated blue, green and red. The sweep was re-run with the same configuration and the bands blended to opaque pale colours. The regenerated results tables are compared with the committed ones in the audit below.

## Compiler settings
pdfLaTeX, then BibTeX (`plain` style), then pdfLaTeX twice (`latexmk -pdf main.tex`). The supplied `epstopdf` setup is unchanged. No `../artifacts` paths or absolute paths are used.

## Claim-to-evidence map
| Report claim (section) | Evidence |
|---|---|
| $x^*$, $q_c$ for $a=0.2$ (0.7055, 0.5251); logistic $rK/4$; steady states of the four regimes (Sec. 2) | `artifacts/tables/wp01_thresholds.json`, `wp01_equilibria.csv`; recomputed with `mm_allee.equilibria` |
| Example steady states $x_-=0.4431$, $x_+=0.9063$ and collapse at $\tau\approx2.93$ (Sec. 2.8) | recomputed with `mm_allee.solver.solve_trajectory` (extinction $\tau=2.932363$) |
| Model B $e_c$, steady states at $e=0.4$ (Sec. 3) | `artifacts/tables/wp02_b_equilibria.csv`; `mm_allee.model_b` |
| Comparison table $N_0=900$, $\alpha=0.5$; mean catches 131.28 / 134.00 / 103.35 (Sec. 3.2) | `artifacts/tables/wp02_comparison.csv` (rows initial_catch and threshold_fraction, N0=900, fraction 0.5) |
| Extinction/smallness times 13.436601, 34.612578, 20.4, 42.0; refinement errors < 2e-9 (Sec. 3.3-3.4) | `artifacts/tables/wp02_history_summary.csv` |
| $N_*=70.5505$, $H_c=36.7597$, $h_c=0.56$, logistic 17.5; $h_{MSY}=0.5210$, margin 6.96%, boundary 49.45; elasticities (Sec. 4.5) | `artifacts/manifests/wp03_summary.json`, `artifacts/tables/wp03_sensitivity.csv`, `wp03_thresholds.csv` |
| Event checks table; bottleneck table; 427 extinction evaluations; reference validation (Sec. 4) | `wp03_event_validation.csv`, `wp03_bottleneck.csv`, `wp03_extinction.csv` (427 rows), `wp03_reference_validation.csv` |
| Forward results table and 18/18 accurate, median 6.4e-6, 3.2-4.6 s, RK45 6e-11 to 1.4e-9 (Sec. 5.6) | `artifacts/tables/wp04_forward_metrics.csv`; 36/36 with `wp04_confirmation_metrics.csv` (median 5.8e-6, range 1.4e-7 to 2.3e-3) |
| Negative-sample counts (23, 61, 1, 1, 1) and near-zero errors (Sec. 5.6) | `wp04_forward_metrics.csv` columns `boundary_violations`, `max_abs_near_zero` |
| Failure diagnostic (3-5 of 10 seeds accurate with uniform grids; 10/10 with denser points near $\tau=0$; residual between points 14-47) (Sec. 5.5) | `artifacts/tables/wp04_diagnose_summary.csv` (lr 1e-2, 10 seeds) |
| Activation comparison tanh 11/18, swish 17/18, sigmoid 10/18 (Sec. 5.5) | `artifacts/tables/wp04_activation_selection.csv` |
| Selection table (tanh 1e-3 18/18 + 10/18 etc.), 64-wide candidate 307 s, score 23 (Sec. 5.5) | `artifacts/tables/shared_stage1_summary.csv`; `experiments/integration/README.md` (64-wide result is from a console log, not a saved table) |
| Clean recovery table 10/18, per-case counts, condition numbers (Sec. 6.5) | `artifacts/tables/wp05_parameter_metrics.csv` (grouped by case at $\sigma=0$; recomputed: A reg 3, A near-fold 0, A ext 1, B reg 3, B near-fold 3, B decline 0); condition numbers from `experiments/integration/README.md` |
| Parameter estimates table (Sec. 6.6) | `wp05_parameter_metrics.csv`, seed 11, regular cases (all 12 rows checked) |
| Cramér-Rao table, noise-floor ratio 0.65-1.15 (median 0.87), 132/144, 12 missed, 8/8/2/1 vs 10/7/2/1 (Sec. 6.6-6.7) | `artifacts/tables/shared_noise_summary.csv`, `shared_noise_nosel_summary.csv`, `experiments/integration/README.md` |
| All 54 fits `iteration_limit` (Sec. 6.7) | `wp05_prediction_metrics.csv` column `lbfgs_outcome` |
| Held-out medians 1.6e-4 / 3.8e-3 / 4.9e-2 (clean reference, all cases); 2.9e-6 / 2.7e-3 / 1.3e-2 (regular cases); against noisy data 1.6e-4 / 1.5e-2 / 9.6e-2; original 1.1e-1 / 1.0e-1 / 1.4e-1 (Sec. 6.8) | `wp05_prediction_metrics.csv` (`test_clean_relative_l2`, `test_relative_l2`) and `wp05_prediction_metrics_original_settings.csv` |

## Open points for the authors (not decided in this draft)
1. **A mislabel in PR #10 text to correct.** `report/sections/05_inverse_validation.tex` and the WP05 notebook on PR #10 say the median held-out errors 1.6e-4 / 3.8e-3 / 4.9e-2 are for "the regular cases". They are medians over all six cases (regular cases alone: 2.9e-6 / 2.7e-3 / 1.3e-2). The original-settings numbers there were measured against noisy observations, so they are not like-for-like with the clean-reference numbers. This report states both correctly; the PR #10 and PR #5 notebook/report text should be changed to match.
2. **AI-use entries.** Raghav's WP01 AI use and any use not in `docs/AI_USAGE.md` must be added by the member; `sections/acknowledgements.tex` states only what the log records.
3. **Bibliography.** Checked against Crossref or arXiv: Raissi et al., Liu and Nocedal, Lagaris et al., Dormand and Prince, Virtanen et al., Kingma and Ba, Ramachandran et al.; Rao (1945) against the Indian Academy of Sciences record; Hairer et al. against library catalogues; JAX from its repository citation. The earlier entries (Courchamp, Stephens, Dennis, Hutchings, Strogatz, Brauer, SciPy pages) were verified earlier in the project (`docs/REFERENCES.md`). Cramér (1946) is a standard textbook cited from memory and was not machine-checked.
4. **Figure 5.2** (`wp04_error_loss`) is a seven-panel figure and its text is small at page width; consider splitting it.
5. Only synthetic data are used; no claim about a real species is made.

## What was and was not checked
Compiled with pdfLaTeX/BibTeX and the pages inspected visually (no missing figures, references or citations). Every number was checked against the saved tables listed above, except those marked as taken from the integration README. The long PINN sweeps are recorded evidence; only the WP05 sweep was re-run, to regenerate two figures. No human review or approval is implied.
