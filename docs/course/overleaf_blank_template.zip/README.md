# Blank Overleaf layout template

This retains the layout of the supplied 30 October Overleaf export. Every report body is intentionally blank, including WP03, abstract, introduction, conclusions and acknowledgements. Scientific figures and the old bibliography have been removed. No report has been written or compiled in this template.

Upload this ZIP to Overleaf as a new project. Set the main document to main.tex and the compiler to pdfLaTeX. Fill each owned sections/*.tex file, add verified references.bib entries and current figures under figures/. Compile main.tex, not an individual section.

The complete writing brief and evidence sources are in PR #5 and docs/REPORT_WRITER_HANDOFF.md in devam2006/mm-allee-harvesting. Existing repository report prose and old ZIP contents are historical sources, not current evidence.
