# Notebook, data and figure handoff

Open project.ipynb in Jupyter and Restart Kernel / Run All. It contains its source/config/data/evidence snapshot and restores it automatically; no repository checkout or dataset download is needed. Install the scientific dependencies listed in the first Markdown cell. The tested environment is in environment.json. The saved notebook includes the actual successful kernel outputs; its ordinary demonstrations are not reruns of all recorded research sweeps.

figures/ includes PNG/EPS pairs and available PDFs; use EPS files in the separately maintained Overleaf report. Historical alternatives are labelled in INVENTORY.json. datasets/ includes clean synthetic fixtures and reconstructed noisy training/validation/test inputs. tables/ and provenance/ preserve recorded evidence and its limitations. source/ contains readable implementation, authoring/experiment scripts and disclosures. Run the notebook directly; source/ is a readable companion, not a second copy of the complete repository layout.

This is a technically verified integration candidate, not certification of optimizer convergence, human approvals, presentation readiness or final Overleaf report.
